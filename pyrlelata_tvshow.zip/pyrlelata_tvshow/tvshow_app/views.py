from django.shortcuts import render, redirect
from . models import *

# Create your views here.

def shows(request):
    shows = Show.objects.all()
    context = {
        "shows": shows,
    }
    return render(request, 'shows.html', context)

def add_form(request):
    if request.method == "GET":

        return render(request, 'new_show.html')

def create_show(request):
    if request.method == "POST":
        title = request.POST['title']
        network = request.POST['network']
        release_date = request.POST['release_date']
        desc = request.POST['desc']
    Show.objects.create(title=title, network=network, release_date=release_date, desc = desc)
    return redirect("/shows")

def show_display(request, show_id):
    show_to_display = Show.objects.get(id=show_id)
    context = {
        "show": show_to_display,
    }
    return render(request, 'show_display.html', context)

def edit_show(request, show_id):
    if request.method == "GET":
        show_to_update = Show.objects.get(id=show_id)
        context = {
            "show": show_to_update,
        }
        
    return render(request, 'edit_show.html', context)

def update_show(request, show_id):
    if request.method == "POST":
        show_to_update = Show.objects.get(id=show_id)
        show_to_update.title = request.POST['title']
        show_to_update.network = request.POST['network']
        show_to_update.release_date = request.POST['release_date']
        show_to_update.desc = request.POST['desc']
        show_to_update.save()
        context = {
            "show": show_to_update,
        }
    
    return redirect(f"/shows/{show_to_update.id}")

def destroy_show(request, show_id):
    show_to_delete = Show.objects.get(id=show_id)
    show_to_delete.delete()
    return redirect("/shows")