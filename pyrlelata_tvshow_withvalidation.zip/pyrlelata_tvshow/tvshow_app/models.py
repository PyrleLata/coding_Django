from django.db import models
from datetime import datetime

# Create your models here.
class ShowManager(models.Manager):
    def basic_validation(self, post_data):
        errors = {}
        if not post_data['title'] or not post_data['network'] or not post_data['release_date']:
            errors['fields_required'] = 'All fields are required'
            return errors
        if datetime.strptime(post_data['release_date'], '%Y-%m-%d') > datetime.now():
            errors['release_date'] = 'Released date should be in the past!'
        # if datetime.strptime(post_data['release_date'], '%Y-%m-%d') == datetime.now() and len(post_data['desc']) < 10:
        #     errors['desc'] = 'Description must be at least 10 characters!'
        # if datetime.strptime(post_data['release_date'], '%Y-%m-%d') == datetime.now():
        #     if len(post_data['desc']) < 10:
        #         errors['desc'] = 'Description must be at least 10 characters!'
        if len(post_data['desc']) < 10:
            errors['desc'] = 'Description must be at least 10 characters!'
        if len(post_data['title']) < 2:
#            print("Invalid!")
            errors['title'] = 'Title must be at least 2 characters!'
        if len(post_data['network']) < 3:
            errors['network'] = 'Network must be at least 3 characters!'
        return errors

class Show(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=45)
    release_date = models.DateField()
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ShowManager()