from django.apps import AppConfig


class TvshowAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tvshow_app'
